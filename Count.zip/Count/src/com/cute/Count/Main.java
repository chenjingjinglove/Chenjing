package com.cute.Count;
import java.io.*;
import java.util.*;
import java.util.Map.Entry;
public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		BufferedReader br = new BufferedReader(new FileReader("E:/word.txt"));
		List<String> lists = new ArrayList<String>();  //存储过滤后单词的列表
		String readLine = null;
		while((readLine = br.readLine()) != null){
		String[] wordsArr1 = readLine.split("[^a-zA-Z]");  //过滤出只含有字母的
		for (String word : wordsArr1) {
			if(word.length() !=0){   //去除长度为0的行
				lists.add(word);
			}
		}
	}
	br.close();
	Map<String,Integer> Count = new TreeMap<String,Integer>();   
	//存储单词计数信息，key值为单词，value为单词数
	
	//单词的词数统计
	for (String li : lists) {
		if(Count.get(li) != null){
			Count.put(li, Count.get(li) + 1);
		}else{
			Count.put(li, 1);
		}
	}
	
	SortMap(Count);   //按值进行排序
}

//按value的大小进行排序
public static void SortMap(Map<String,Integer> oldmap) throws IOException{
	ArrayList<Map.Entry<String, Integer>> list = 
			new ArrayList<Map.Entry<String,Integer>>(oldmap.entrySet());
	Collections.sort(list,new Comparator<Map.Entry<String, Integer>>(){
		
		@Override
		public int compare(Entry<String,Integer> o1, Entry<String,Integer> o2){
			return o2.getValue() - o1.getValue();  //降序
		}
	});
	
	 String filePath= "E:/";
	File file = new File(filePath+"result.txt"); 
     if(!file.getParentFile().exists()){ //如果文件的目录不存在
         file.getParentFile().mkdirs(); //创建目录
         
     }  
     //2: 实例化OutputString 对象
     OutputStream output = null;
	try {
		output = new FileOutputStream(file);
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	String  msg="";
     //3: 准备好实现内容的输出
	for(int i = 0; i<list.size(); i++){
		msg+=  list.get(i).getKey()+": "+list.get(i).getValue()+"\r\n";
    }
  
     //将字符串变为字节数组
     byte data[] = msg.getBytes();
     output.write(data);
   //4: 资源操作的最后必须关闭
     output.close();
     System.out.print("文件输出成功\n");
	
     Scanner sc=new Scanner(System.in);
     System.out.println("输入需要查找的单词-------");
     String testString=sc.nextLine();
     sc.close();
     
     for(int i = 0; i<list.size(); i++){
    	 if(testString.equals(list.get(i).getKey())){
    		  System.out.println(list.get(i).getKey()+": "+list.get(i).getValue()+"\r\n");
    	 }
    	 
     }
}

}